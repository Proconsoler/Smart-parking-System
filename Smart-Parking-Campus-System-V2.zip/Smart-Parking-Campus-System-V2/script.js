/* ═══════════════════════════════════════════════
   SMART PARKING — Full script.js with RTO City Detection
═══════════════════════════════════════════════ */

const API_BASE = '/api';

async function fetchAPI(endpoint, options = {}) {
    try {
        const res = await fetch(API_BASE + endpoint, {
            headers: { 'Content-Type': 'application/json' },
            ...options
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Server Error');
        }
        return res.json();
    } catch (e) {
        console.error("API Error:", e);
        throw e;
    }
}

// ==================== RTO CITY MAPPING ====================
const rtoMapping = {
    "DL": "Delhi",
    "DL1": "North Delhi", "DL2": "West Delhi", "DL3": "South Delhi", "DL4": "East Delhi",
    "DL5": "Central Delhi", "DL6": "North East Delhi", "DL7": "Shahadara", "DL8": "South West Delhi",
    "DL9": "North West Delhi",

    "UP": "Uttar Pradesh",

    "UP11": "Saharanpur",
    "UP12": "Muzaffarnagar",
    "UP13": "Bulandshahr",
    "UP14": "Ghaziabad",
    "UP15": "Meerut",
    "UP16": "Noida (Gautam Buddha Nagar)",
    "UP17": "Baghpat",
    "UP19": "Shamli",

    "UP20": "Bijnor",
    "UP21": "Moradabad",
    "UP22": "Rampur",
    "UP23": "Jyotiba Phule Nagar (Amroha)",
    "UP24": "Badaun",
    "UP25": "Bareilly",
    "UP26": "Pilibhit",
    "UP27": "Shahjahanpur",

    "UP30": "Hardoi",
    "UP31": "Lakhimpur Kheri",
    "UP32": "Lucknow",
    "UP33": "Raebareli",
    "UP34": "Sitapur",
    "UP35": "Unnao",

    "UP40": "Bahraich",
    "UP41": "Barabanki",
    "UP42": "Faizabad (Ayodhya)",
    "UP43": "Gonda",
    "UP44": "Sultanpur",
    "UP45": "Ambedkar Nagar",
    "UP46": "Shrawasti",
    "UP47": "Balrampur",

    "UP50": "Azamgarh",
    "UP51": "Basti",
    "UP52": "Deoria",
    "UP53": "Varanasi",
    "UP54": "Gorakhpur",
    "UP55": "Jaunpur",
    "UP56": "Mau",
    "UP57": "Padrauna (Kushinagar)",
    "UP58": "Sant Kabir Nagar",
    "UP60": "Ballia",

    "UP61": "Ghazipur",
    "UP62": "Sonbhadra",
    "UP63": "Mirzapur",
    "UP64": "Chandauli",

    "UP65": "Allahabad (Prayagraj)",
    "UP66": "Fatehpur",
    "UP67": "Pratapgarh",
    "UP70": "Kaushambi",

    "UP71": "Etawah",
    "UP72": "Farrukhabad",
    "UP73": "Kannauj",
    "UP74": "Kanpur Dehat",
    "UP75": "Kanpur Nagar",
    "UP76": "Auraiya",

    "UP77": "Firozabad",
    "UP78": "Mainpuri",
    "UP79": "Etah",
    "UP80": "Agra",
    "UP81": "Aligarh",
    "UP82": "Hathras",
    "UP83": "Kasganj",

    "UP84": "Mathura",

    "HR": "Haryana",

    "HR01": "Ambala",
    "HR02": "Yamunanagar",
    "HR03": "Panchkula",
    "HR04": "Naraingarh",
    "HR05": "Karnal",
    "HR06": "Panipat",
    "HR07": "Kurukshetra",
    "HR08": "Kaithal",

    "HR09": "Gurugram",
    "HR10": "Faridabad",
    "HR11": "Sonipat",
    "HR12": "Rohtak",
    "HR13": "Bhiwani",
    "HR14": "Jhajjar",
    "HR15": "Jind",
    "HR16": "Hisar",

    "HR17": "Fatehabad",
    "HR18": "Sirsa",
    "HR19": "Dabwali",
    "HR20": "Nuh",

    "HR21": "Mahendragarh",
    "HR22": "Rewari",

    "HR23": "Palwal",

    

    "MH": "Maharashtra",
    "MH01": "Mumbai", "MH02": "Mumbai Suburban", "MH12": "Pune",

    "PB": "Punjab", "RJ": "Rajasthan", "MP": "Madhya Pradesh", "GJ": "Gujarat",
    "KA": "Karnataka", "TN": "Tamil Nadu", "WB": "West Bengal", "BR": "Bihar"
};

function detectRTO(vehicleNumber) {
    const cityInput = document.getElementById('city');
    if (!cityInput) return;

    vehicleNumber = vehicleNumber.trim().toUpperCase();
    if (vehicleNumber.length < 2) {
        cityInput.value = "";
        return;
    }

    let detectedCity = "Unknown City";

    // Check for longer codes first (most specific)
    const codes = Object.keys(rtoMapping).sort((a, b) => b.length - a.length);
    for (let code of codes) {
        if (vehicleNumber.startsWith(code)) {
            detectedCity = rtoMapping[code];
            break;
        }
    }

    cityInput.value = detectedCity;
    console.log("Detected City for", vehicleNumber, "→", detectedCity); // For debugging
}

// ==================== THEME ====================
function toggleTheme() {
    document.body.classList.toggle('light-mode');
    localStorage.setItem('theme', document.body.classList.contains('light-mode') ? 'light' : 'dark');
}

function applyTheme() {
    if (localStorage.getItem('theme') === 'light') document.body.classList.add('light-mode');
}

// ==================== TOAST ====================
function showToast(msg, type = 'info') {
    let toast = document.getElementById('toast') || document.createElement('div');
    toast.id = 'toast';
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span> ${msg}`;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('show'));
    setTimeout(() => toast.classList.remove('show'), 3200);
}

// ==================== LOGIN ====================
async function saveUserDetails() {
    const name = document.getElementById('name').value.trim();
    const role = document.getElementById('role').value;
    const vehicle = document.getElementById('vehicle').value.trim().toUpperCase();
    const vehicleType = document.getElementById('vehicleType').value;
    const city = document.getElementById('city').value;

    if (!name) return showToast('Please enter your name', 'error');
    if (!role) return showToast('Please select your role', 'error');
    if (!vehicle) return showToast('Please enter your vehicle number', 'error');
    if (!vehicleType) return showToast('Please select vehicle type', 'error');
    if (!city || city === "Unknown City") {
        return showToast('Could not detect city. Please check vehicle number format.', 'error');
    }

    try {
        const data = await fetchAPI('/login', {
            method: 'POST',
            body: JSON.stringify({ name, role, vehicle, vehicleType, city })
        });

        localStorage.setItem('userName', data.user.name);
        localStorage.setItem('userRole', data.user.role);
        localStorage.setItem('vehicleNumber', data.user.vehicle);
        localStorage.setItem('vehicleType', data.user.vehicleType);
        localStorage.setItem('city', data.user.city || city);

        showToast('Login successful!', 'success');
        setTimeout(() => window.location.href = 'dashboard.html', 800);
    } catch (err) {
        showToast(err.message || 'Login failed', 'error');
    }
}

function logout() {
    localStorage.clear();
    window.location.href = 'login.html';
}

function requireAuth() {
    if (!localStorage.getItem('userName')) window.location.href = 'login.html';
}

// ==================== USER INFO ====================
function fillUserInfo() {
    requireAuth();
    const name = localStorage.getItem('userName') || 'User';
    const role = localStorage.getItem('userRole') || 'Student';
    const vehicle = localStorage.getItem('vehicleNumber') || '—';
    const vehicleType = localStorage.getItem('vehicleType') || '—';
    const city = localStorage.getItem('city') || '—';

    const nameEl = document.getElementById('displayName');
    const roleEl = document.getElementById('displayRole');
    const vehicleEl = document.getElementById('displayVehicle');

    if (nameEl) nameEl.textContent = name;
    if (roleEl) {
        const roleBadge = { Student: 'badge-purple', Faculty: 'badge-blue', Visitor: 'badge-amber' };
        roleEl.innerHTML = `<span class="badge ${roleBadge[role] || 'badge-purple'}">${role}</span>`;
    }
    if (vehicleEl) vehicleEl.textContent = `${vehicle} (${vehicleType})`;

    const sidebarName = document.getElementById('sidebarName');
    const sidebarRole = document.getElementById('sidebarRole');
    if (sidebarName) sidebarName.textContent = name;
    if (sidebarRole) sidebarRole.textContent = role;
}

// ==================== PARKING GRID ====================
async function getSlots() {
    const data = await fetchAPI('/slots');
    return data.slots;
}

async function loadParkingGrid() {
    const grid = document.getElementById('parkingGrid');
    if (!grid) return;
    try {
        const slots = await getSlots();
        grid.innerHTML = '';
        const statusLabel = { available: 'Free', booked: 'Booked', occupied: 'In Use', reserved: 'Reserved' };

        slots.forEach(slot => {
            const div = document.createElement('div');
            div.className = `slot ${slot.status}`;
            div.setAttribute('data-slot', slot.id);
            div.innerHTML = `${slot.id}<span class="slot-label">${statusLabel[slot.status] || slot.status}</span>`;

            if (slot.status === 'available') {
                div.onclick = () => window.location.href = `booking.html?slot=${slot.id}`;
            }
            grid.appendChild(div);
        });
        updateDashboardStats(slots);
    } catch (e) {
        showToast('Failed to load parking slots', 'error');
    }
}

function updateDashboardStats(slots) {
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('totalSlots', 50);
    set('availableCount', slots.filter(x => x.status === 'available').length);
    set('bookedCount', slots.filter(x => x.status === 'booked').length);
    set('occupiedCount', slots.filter(x => x.status === 'occupied').length);
    set('reservedCount', slots.filter(x => x.status === 'reserved').length);
}

// ==================== BOOKING ====================
async function initBookingPage() {
    requireAuth();
    const urlParams = new URLSearchParams(window.location.search);
    const slotParam = urlParams.get('slot');
    if (slotParam) document.getElementById('slot').value = slotParam;

    const role = localStorage.getItem('userRole');
    const zoneMap = { Student: 'Student Zone', Faculty: 'Faculty Zone', Visitor: 'Visitor Zone' };
    if (role && zoneMap[role]) document.getElementById('zone').value = zoneMap[role];

    const vehicleType = localStorage.getItem('vehicleType') || '—';
    const vehicleDisplay = document.getElementById('bookingVehicle');
    if (vehicleDisplay) {
        vehicleDisplay.textContent = `${localStorage.getItem('vehicleNumber') || '—'} (${vehicleType})`;
    }

    document.getElementById('bookingUserName').textContent = localStorage.getItem('userName') || '—';

    const dateInput = document.getElementById('date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
        dateInput.value = today;
    }
}

async function bookSlot() {
    const slot = document.getElementById('slot').value;
    const zone = document.getElementById('zone').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const name = localStorage.getItem('userName');
    const vehicle = localStorage.getItem('vehicleNumber');

    if (!slot || !zone || !date || !time) return showToast('Please fill all fields', 'error');

    try {
        const res = await fetchAPI('/book', {
            method: 'POST',
            body: JSON.stringify({ slotId: slot, name, vehicle, zone, date, time })
        });

        localStorage.setItem('bookingId', res.bookingId);
        localStorage.setItem('bookedSlot', slot);
        localStorage.setItem('bookedZone', zone);
        localStorage.setItem('bookedDate', date);
        localStorage.setItem('bookedTime', time);

        showToast('Booking confirmed!', 'success');
        setTimeout(() => window.location.href = 'confirmation.html', 800);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Confirmation
function fillConfirmation() {
    requireAuth();
    const vehicleType = localStorage.getItem('vehicleType') || '';
    const vehicleStr = localStorage.getItem('vehicleNumber') || '—';
    const fullVehicle = vehicleType ? `${vehicleStr} (${vehicleType})` : vehicleStr;

    const fields = {
        bookingId: localStorage.getItem('bookingId') || 'SP100001',
        confirmName: localStorage.getItem('userName') || '—',
        confirmVehicle: fullVehicle,
        confirmSlot: localStorage.getItem('bookedSlot') || '—',
        confirmZone: localStorage.getItem('bookedZone') || '—',
        confirmDate: localStorage.getItem('bookedDate') || '—',
        confirmTime: localStorage.getItem('bookedTime') || '—'
    };

    Object.entries(fields).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    });

    generateQRCode(fields.bookingId, fields.confirmName, fields.confirmVehicle, fields.confirmSlot, fields.confirmZone, fields.confirmDate, fields.confirmTime);
}

function generateQRCode(bookingId, name, vehicle, slot, zone, date, time) {
    const qrContainer = document.getElementById('qrcode');
    if (!qrContainer || typeof QRCode === 'undefined') return;
    qrContainer.innerHTML = '';
    const qrData = `Booking ID: ${bookingId}\nName: ${name}\nVehicle: ${vehicle}\nSlot: ${slot}\nZone: ${zone}\nDate: ${date}\nTime: ${time}`;
    new QRCode(qrContainer, { text: qrData, width: 150, height: 150 });
}

// Admin, Logs, Reports (kept minimal but functional)
async function loadAdminData() {
    const tbody = document.getElementById('adminTable');
    if (!tbody) return;
    try {
        const bookings = await fetchAPI('/admin/bookings');
        if (bookings.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--muted);">No active bookings</td></tr>`;
            return;
        }
        tbody.innerHTML = bookings.map(b => `
            <tr>
                <td><strong>${b.name}</strong></td>
                <td><span class="text-mono">${b.vehicle}</span></td>
                <td><span class="badge badge-purple">#${b.slotId}</span></td>
                <td>${b.zone}</td>
                <td>${b.date} ${b.time}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="adminReleaseSlot(${b.slotId})" style="margin-right:6px;">Release</button>
                    <button class="btn btn-amber btn-sm" onclick="adminMarkOccupied(${b.slotId})">Mark Occupied</button>
                </td>
            </tr>
        `).join('');
        await loadLogs();
    } catch (e) {
        showToast('Failed to load admin data', 'error');
    }
}

async function adminReleaseSlot(slotId) {
    if (!confirm(`Release slot ${slotId}?`)) return;
    try {
        await fetchAPI(`/book/${slotId}`, { method: 'DELETE' });
        showToast(`Slot ${slotId} released`, 'success');
        loadAdminData();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function adminMarkOccupied(slotId) {
    if (!confirm(`Mark slot ${slotId} as Occupied?`)) return;
    try {
        await fetchAPI(`/book/${slotId}/occupy`, { method: 'PUT' });
        showToast(`Slot ${slotId} marked as Occupied`, 'success');
        loadAdminData();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function loadLogs() {
    const logsEl = document.getElementById('logsContainer');
    if (!logsEl) return;
    try {
        const logsData = await fetchAPI('/logs');
        if (logsData.length === 0) {
            logsEl.innerHTML = '<p class="text-muted" style="padding:12px;">No activity yet.</p>';
            return;
        }
        logsEl.innerHTML = logsData.map(l => `
            <div class="log-entry">
                <span class="log-time">${l.time}</span>
                <span>${l.msg}</span>
            </div>
        `).join('');
    } catch (e) { }
}

async function clearLogs() {
    if (!confirm('Clear all activity logs?')) return;
    try {
        await fetchAPI('/logs', { method: 'DELETE' });
        showToast('Logs cleared', 'info');
        loadLogs();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function loadReports() {
    try {
        const data = await fetchAPI('/reports');
        const el = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
        el('rptOccupancy', data.occupancyPercent + '%');
        el('rptBooked', data.summary.booked);
        el('rptAvailable', data.summary.available);
        el('rptOccupied', data.summary.occupied);
    } catch (e) {
        showToast('Failed to load reports', 'error');
    }
}

// Init
document.addEventListener('DOMContentLoaded', () => {
    applyTheme();
});