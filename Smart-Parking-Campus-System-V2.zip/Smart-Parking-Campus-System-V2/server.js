// ==================== NEW server.js (Full Backend) ====================

const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

const TOTAL_SLOTS = 50;
const ZONES = ['Student Zone', 'Faculty Zone', 'Visitor Zone'];

let slots = [];
let users = [];
let logs = [];

function initSlots() {
    slots = [];
    for (let i = 1; i <= TOTAL_SLOTS; i++) {
        let status = 'available';
        if (i % 7 === 0) status = 'booked';
        if (i % 11 === 0) status = 'occupied';
        if (i % 17 === 0) status = 'reserved';
        const zone = ZONES[Math.floor((i - 1) / (TOTAL_SLOTS / ZONES.length))];
        slots.push({ id: i, status, zone: zone || ZONES[0], bookedBy: null });
    }
}
initSlots();

function addLog(msg) {
    logs.unshift({ msg, time: new Date().toLocaleString() });
    if (logs.length > 200) logs.pop();
}

// Login
app.post('/api/login', (req, res) => {
    const { name, role, vehicle } = req.body;
    if (!name || !role || !vehicle) return res.status(400).json({ error: 'All fields required' });

    let user = users.find(u => u.vehicle === vehicle.toUpperCase());
    if (!user) {
        user = { id: 'USR' + Math.floor(Math.random() * 100000), name, role, vehicle: vehicle.toUpperCase() };
        users.push(user);
    }
    addLog(`User ${name} (${role}) logged in`);
    res.json({ success: true, user });
});

// Get all slots
app.get('/api/slots', (req, res) => {
    const stats = {
        total: slots.length,
        available: slots.filter(s => s.status === 'available').length,
        booked: slots.filter(s => s.status === 'booked').length,
        occupied: slots.filter(s => s.status === 'occupied').length,
        reserved: slots.filter(s => s.status === 'reserved').length,
    };
    res.json({ slots, stats });
});

// Book a slot
app.post('/api/book', (req, res) => {
    const { slotId, name, vehicle, zone, date, time } = req.body;
    if (!slotId || !name || !vehicle || !zone || !date || !time) {
        return res.status(400).json({ error: 'All fields required' });
    }

    const slot = slots.find(s => s.id === parseInt(slotId));
    if (!slot) return res.status(404).json({ error: 'Slot not found' });
    if (slot.status !== 'available') {
        return res.status(409).json({ error: `Slot ${slotId} is not available` });
    }

    const bookingId = 'SP' + Math.floor(Math.random() * 900000 + 100000);
    slot.status = 'booked';
    slot.bookedBy = { name, vehicle: vehicle.toUpperCase(), zone, date, time, bookingId };

    addLog(`Slot ${slotId} booked by ${name} (${vehicle}) — ${zone}`);

    res.json({ success: true, bookingId, slot });
});

// Release slot (Admin)
app.delete('/api/book/:slotId', (req, res) => {
    const slot = slots.find(s => s.id === parseInt(req.params.slotId));
    if (!slot) return res.status(404).json({ error: 'Slot not found' });

    const prev = slot.bookedBy?.name || 'unknown';
    slot.status = 'available';
    slot.bookedBy = null;
    addLog(`Admin released slot ${slot.id} (was booked by ${prev})`);
    res.json({ success: true });
});

// Admin bookings
app.get('/api/admin/bookings', (req, res) => {
    const bookings = slots
        .filter(s => s.status === 'booked' && s.bookedBy)
        .map(s => ({ slotId: s.id, zone: s.zone, ...s.bookedBy }));
    res.json(bookings);
});

// Reset all
app.post('/api/admin/reset', (req, res) => {
    initSlots();
    logs = [];
    addLog('Admin reset all slots');
    res.json({ success: true, message: 'All slots reset' });
});

// Logs
app.get('/api/logs', (req, res) => res.json(logs));

app.delete('/api/logs', (req, res) => {
    logs = [];
    addLog('Logs cleared by admin');
    res.json({ success: true });
});

// Reports
app.get('/api/reports', (req, res) => {
    const total = slots.length;
    const booked = slots.filter(s => s.status === 'booked').length;
    const occupied = slots.filter(s => s.status === 'occupied').length;
    const available = slots.filter(s => s.status === 'available').length;
    const reserved = slots.filter(s => s.status === 'reserved').length;

    const zoneStats = {};
    slots.filter(s => s.status === 'booked' && s.bookedBy).forEach(s => {
        const z = s.bookedBy.zone || 'Unknown';
        zoneStats[z] = (zoneStats[z] || 0) + 1;
    });

    res.json({
        summary: { total, booked, occupied, available, reserved },
        occupancyPercent: Math.round(((booked + occupied) / total) * 100),
        zoneStats,
    });
});

app.listen(PORT, () => {
    console.log(`✅ Smart Parking server running at http://localhost:${PORT}`);
    console.log(`   Open browser → http://localhost:3000/login.html`);
});